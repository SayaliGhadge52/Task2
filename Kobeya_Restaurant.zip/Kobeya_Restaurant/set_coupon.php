<?php
include 'includes/_dbconnect.php';
include 'includes/function.php';
$coupon_code=get_safe_value($_POST['coupon_code']);
$res=mysqli_query($conn,"select * from coupon_code where coupon_code='$coupon_code'");
//$check=(!$res)?mysqli_num_rows($res):0;
if(mysqli_num_rows($res)>0){
    $row=mysqli_fetch_assoc($res);	
	
	$arr=array('status'=>'success','msg'=>'coupon code applay.','final_value'=>$row['coupon_value']);

}else{
	$arr=array('status'=>'error','msg'=>'Please enter valid coupon code.');
}
echo json_encode($arr);

?>