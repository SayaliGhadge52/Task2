<?php

 include 'includes/_dbconnect.php';
 
 
$productCategorieId=$_GET['productCategorieId'];
if($productCategorieId=='23')
{
	$sql = "SELECT * FROM `categories` WHERE categorieName = 'Breakfast' ";
}
elseif($productCategorieId=='24') {
	$sql = "SELECT * FROM `categories` WHERE categorieName = 'Appetizer & Soup' ";
}
elseif($productCategorieId=='25') {
	$sql = "SELECT * FROM `categories` WHERE categorieName = 'Salad' ";
}
elseif($productCategorieId=='26') {
	$sql = "SELECT * FROM `categories` WHERE categorieName = 'Main' ";
}
elseif($productCategorieId=='29') {
	$sql = "SELECT * FROM `categories` WHERE categorieName = 'Beverages' ";
}
elseif($productCategorieId=='27') {
	$sql = "SELECT * FROM `categories` WHERE categorieName = 'Combo' ";
}
elseif($productCategorieId=='28') {
	$sql = "SELECT * FROM `categories` WHERE categorieName = 'Dessert' ";
}
elseif($productCategorieId=='30') {
	$sql = "SELECT * FROM `categories` WHERE categorieName = 'Coffee & Tea' ";
}
elseif($productCategorieId=='31') {
	$sql = "SELECT * FROM `categories` WHERE categorieName = 'Kids Menu' ";
}
elseif($productCategorieId=='32') {
	$sql = "SELECT * FROM `categories` WHERE categorieName = 'Occasion Cakes' ";
}
else
{
	$sql = "SELECT * FROM `categories`";
}

  $query=mysqli_query($conn,$sql);
  while($row=mysqli_fetch_array($query)){
	  echo $row['categorieDesc'];
  }
?>