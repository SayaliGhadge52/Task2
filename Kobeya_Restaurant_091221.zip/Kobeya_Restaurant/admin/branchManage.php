<div class="container-fluid" style="margin-top:98px">
    <div class="col-lg-12">
        <div class="row">
            <!-- FORM Panel -->
            <div class="col-md-4">
                <form action="includes/_couponManage.php" method="post" enctype="multipart/form-data">
                    <div class="card">
                        <div class="card-header" style="color:#FFFFFF; background-color:#426047 !important;">
                           <strong> Add Branch | KOBEYa Restuarant </strong>
                        </div>
                        <div class="card-body">
						    <b><h5 class="card-title">Basic Information</h5></b>
                            <p class="card-title-desc">Fill all information below</p>
                            <div class="form-group">
                                <label class="control-label">Branch Name</label>
                                <input type="text" class="form-control" name="branchname" required>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Branch Code</label>
                                <input type="text" class="form-control" name="branchcode" required>
                            </div> 
							<div class="form-group">
                                <label class="control-label">Contact Person</label>
                                <input type="text" class="form-control" name="cperson" required>
                            </div>
							<div class="form-group">
                                <label class="control-label">Location</label>
                                <input type="text" class="form-control" name="location" required>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Contact No</label>
                                <input type="text" class="form-control" name="contactno" required>
                            </div>
							<div class="form-group">
                                <label class="control-label">Email Id</label>
                                <input type="email" class="form-control" name="email" required>
                            </div> 
                        </div>  
						
			            
                       
			
			<div class="card">
                <div class="card-body" style="width: 38rem;">
        
                 <strong><h4 class="card-title">Branch Timing</h4></strong>
                 <p class="card-title-desc">Fill all information below</p>
        
					<?php
						$array = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
						$string = implode(',', $array);
						$i=0;											
						for($i=0;$i<7;$i++){
																		
                        echo'<div class="" style="width:100%;padding:5px 15px;" id="">
											
						<div class="after-add-more1 row" style="width:100%;padding:5px 15px;" id="item_detail">
						<div class="col-lg-3 p-t-20"> 
						<input name="itemName[]" type="text" value="'.$array[$i].'" placeholder="Day" class="form-control input-height emp" >
						</div>
										
						<div class="col-lg-3 p-t-20"> 
						<input name="itemName[]" type="text" placeholder="StartTime" class="form-control input-height emp" >
						</div>
											
						<div class="col-lg-3 p-t-20"> 
						<input name="itemName[]" type="text" placeholder="EndTime" class="form-control input-height emp" >
						</div>
											
						</div>
					    </div>';
										
						 } 
											 
						 ?>	
                        </div>
                    </div>
			            <div class="card-footer">
                            <div class="row">
                                <div class="col-md-12">
                                    <button type="submit" name="createCoupon" class="btn btn-sm btn-primary col-sm-3 offset-md-4" style="background-color:#426047 !important;"> Create </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <!-- FORM Panel -->
    
            <!-- Table Panel -->
            <div class="col-md-8 mb-3">
                <div class="card">
                    <div class="card-body">
                    <table class="table table-bordered table-hover mb-0">
                        <thead style="color:#FFFFFF; background-color:#426047;">
                        <tr>
                            <th class="text-center" style="width:5%;">Id</th>
                            <th class="text-center" style="width:7%;">Branch Name</th>
                            <th class="text-center" style="width:7%;">Branch Code</th>
							<th class="text-center" style="width:7%;">Contact Person</th>
							<th class="text-center" style="width:7%;">Location</th>
							<th class="text-center" style="width:9%;">Contact No</th>
                            <th class="text-center" style="width:9%;">Email Id</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php 
                            $sql = "SELECT * FROM `coupon_code`"; 
                            $result = mysqli_query($conn, $sql);
                            while($row = mysqli_fetch_assoc($result)){
                                $id = $row['id'];
                                $c_code = $row['coupon_code'];
                                $c_type = $row['coupon_type'];
								$c_value = $row['coupon_value'];
								$cartMin = $row['cart_min_value'];
								$exp_on = $row['expired_on'];

                                echo '<tr>
                                        <td class="text-center"><b>' .$id. '</b></td>
                                        <td class="text-center"><b></b></td>
                                        <td class="text-center"><b></b></td>
										<td class="text-center"><b></b></td>
										<td class="text-center"><b></b></td>
										<td class="text-center"><b></b></td>
                                        <td class="text-center">
                                            <div class="row mx-auto" style="width:112px">
                                            <!--<button class="btn btn-sm btn-primary edit_coupon" style="background-color: #426047"  type="button" data-toggle="modal" data-target="#updateCat' .$id. '"><i class="fas fa-edit"></i></button>-->
                                            <form action="includes/_couponManage.php" method="POST">
                                                <!--<button name="removeCoupon" class="btn btn-sm btn-danger" style="margin-left:9px;"><i class="fas fa-trash"></i></button>-->
                                                <input type="hidden" name="id" value="'.$id. '">
                                            </form></div>
                                        </td>
                                    </tr>';
                            }
                        ?> 
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            <!-- Table Panel -->
        </div>
    </div>	    
</div>


<?php 
    $couponsql = "SELECT * FROM `coupon_code`";
    $couponResult = mysqli_query($conn, $couponsql);
    while($couponRow = mysqli_fetch_assoc($couponResult)){
        $id = $couponRow['id'];
        $c_code = $couponRow['coupon_code'];
        $c_type = $couponRow['coupon_type'];
		$c_value = $couponRow['coupon_value'];
		$cartMin = $couponRow['cart_min_value'];
		$exp_on = $couponRow['expired_on'];
?>


<!-- Modal -->
<div class="modal fade" id="updateCat<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="updateCoupon<?php echo $id; ?>" aria-hidden="true" style="width: -webkit-fill-available;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #426047 !important;">
        <h5 class="modal-title" id="updateCoupon<?php echo $id; ?>">Coupon Id: <b><?php echo $id; ?></b></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="includes/_couponManage.php" method="post">
            <div class="text-left my-2">
                <b><label for="code">Coupon Code</label></b>
                <input class="form-control" id="code" name="code" value="<?php echo $c_code; ?>" type="text" required>
            </div>
            <div class="text-left my-2">
                <b><label for="type">Coupon Type</label></b>
                <input class="form-control" id="type" name="type" value="<?php echo $c_type; ?>" type="text" required>
            </div>
			<div class="text-left my-2">
                <b><label for="value">Coupon Amount</label></b>
                <input class="form-control" id="value" name="value" value="<?php echo $c_value; ?>" type="text" required>
            </div>
			<div class="text-left my-2">
                <b><label for="minvalue">Cart Min Amount</label></b>
                <input class="form-control" id="minvalue" name="minvalue" value="<?php echo $cartMin; ?>" type="text" required>
            </div>
			<div class="text-left my-2">
                <b><label for="exp_on">Expired On</label></b>
                <input class="form-control" id="exp_on" name="exp_on" value="<?php echo $exp_on; ?>" type="text" required>
            </div>
            <input type="hidden" id="id" name="id" value="<?php echo $id; ?>">
            <button type="submit" class="btn btn-success" style="background-color:#426047 !important;" name="updateCoupon">Update</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php
    }
?>