<?php
include 'includes/_dbconnect.php';

?>


<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
<style>
/*----------------------------*\
	Search
\*----------------------------*/

.header-search {
  padding: 15px 0px;
}

.header-search form {
  position: relative;
}

.header-search form .input-select {
  margin-right: -4px;
  border-radius: 40px 0px 0px 40px;
}

.header-search form .input {
  width: calc(100% - 260px);
  margin-right: -4px;
}

.header-search form .search-btn {
  height: 40px;
  width: 100px;
 background: #00B4DB;  /* fallback for old browsers */
background: -webkit-linear-gradient(to bottom, #0083B0, #00B4DB);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to bottom, #0083B0, #00B4DB); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */



  color: #FFF;
  font-weight: 700;
  border: none;
  border-radius: 0px 40px 40px 0px;
}

</style>
</head>
<body>
<?php include 'includes/_dbconnect.php';?>


<div class="header-search">

<form method="get" action="test.php" class="form-inline my-2 my-lg-0 mx-3" name="searchform" onSubmit="return dosearch();">
<select class="input-select" name="sengines">
<option value="" selected>Select</option>
<option value="viewProductList.php?catid=23">Breakfast</option>
<option value="viewProductList.php?catid=24">Appetizer & Soup</option>
<option value="viewProductList.php?catid=25">Salad</option>
<option value="viewProductList.php?catid=26">Main</option>
<option value="viewProductList.php?catid=29">Beverages</option>
<option value="viewProductList.php?catid=27">Combo</option>
<option value="viewProductList.php?catid=28">Dessert</option>
<option value="viewProductList.php?catid=30">Coffee & Tea</option>
<option value="viewProductList.php?catid=31">Kids Menu</option>
<option value="viewProductList.php?catid=32">Occasion Cakes</option>
</select>
<input class="form-control mr-sm-2" type="search" name="search" id="search" placeholder="Search" aria-label="Search" >
<input class="btn btn-outline-success my-2 my-sm-0" name="SearchSubmit" type="submit" style="background-color:#426047 !important;border-color:#426047 !important; color:white !important;" value="Search">
</form>
</div>

<script type="text/javascript">
function dosearch() {
var sf=document.searchform;
var submitto = sf.sengines.options[sf.sengines.selectedIndex].value + escape(sf.search.value);
window.location.href = submitto;
return false;
}
</script>

</body>
</html>

