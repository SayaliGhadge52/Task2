<!doctype html>
<html lang="en">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


	
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title>Home</title>
    <link rel = "icon" href ="img/kfavicon.png" type = "image/x-icon">
	
	
	<style>
body {
    font-family: "open_sansregular" !important;
	
}
	
.showcase-area {
  height: 50vh;
  background: linear-gradient(
      rgba(240, 240, 240, 0.144),
      rgba(255, 255, 255, 0.336)
    ),
    url("img/banner.png");
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}



.main-title {
  text-transform: uppercase;
  margin-top: 1.5em;
}

/*.wrapper-flex {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}*/

/*@media only screen and (max-width: 990px)
.col, .col-1, .col-10, .col-11, .col-12, .col-2, .col-3, .col-4, .col-5, .col-6, .col-7, .col-8, .col-9, .col-auto, .col-lg, .col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-auto, .col-md, .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-auto, .col-sm, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-auto, .col-xl, .col-xl-1, .col-xl-10, .col-xl-11, .col-xl-12, .col-xl-2, .col-xl-3, .col-xl-4, .col-xl-5, .col-xl-6, .col-xl-7, .col-xl-8, .col-xl-9, .col-xl-auto {
    padding-left: 15px;
    padding-right: 15px;
    max-width: 100%;
    float: left;
    width: 100%;
    flex: auto;*/
@media (min-width: 500px) {
  .wrapper {
    flex-wrap: wrap;
    display: flex;
    justify-content: space-between;
  }
}

#sidebar-wrapper {
    min-width: 200px;
    max-width: 250px;
    min-height: 100vh;
	background: #f3f6f4;
    color: #fff;
    transition: all 0.2s;
}

#sidebar-wrapper .sidebar-heading {
 padding: 20px;
 background: #6d7fcc;
}

#sidebar-wrapper .list-group {
   padding: 25px 0;
   border-bottom: 1px solid #eeeeee;
}

.list-group-item-light {
	font-size: 0.9em !important;
    padding-left: 30px !important;
    
    color: #000000;
    background-color: #f1f1f1;
}

.page-wrapper {
  position: relative;
  transition: margin 0.4s, opacity 0.5s;
}
.loaded > .page-wrapper {
  opacity: 1;
}

/* sidebar */
.shop-sidebar {
  position: relative;
}
.shop-sidebar .widget-body {
  margin-bottom: 1rem;
}
	</style>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
  </head>
<body>
  <?php include 'includes/_dbconnect.php';?>
  <?php require 'includes/_nav.php' ?>
  
  <!-- Category container starts here -->
  
  
  

  

  
  
  
  
  <section class="showcase-area" id="showcase">
      <div class="showcase-container">
        <h1 class="main-title" id="home"></h1>
        <p></p>
       
      </div>
    </section>
  

  
  <div class="container my-3 mb-5">
    <div class="col-lg-2 text-center bg-light my-3" style="margin:auto;border-bottom: 2px; color:#426047 !important;">     
      <h2 class="text-center">Menu</h2>
    </div>
	 <!--sidebar start-->
	 <div class="d-flex align-items" id="page-content-wrapper">
	   <div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-light"><a href="index-Copy.php">Food Categories</a></div>	
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=23">Breakfast</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=24">Appetizer & Soup</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=25">Salad</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=26">Main</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=29">Beverages</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=27">Combo</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=28">Dessert</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=30">Coffee & Tea</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=31">Kids Menu</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="viewProductList.php?catid=32">Occasion Cakes</a>
                </div>
    </div>
    <!--sidebar end-->
    <div class="row">

      <?php 
        $sql = "SELECT * FROM `product`"; 
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result)){
          $id = $row['productId'];
          $cat = $row['productName'];
          $desc = $row['productDesc'];
		  $productPrice = $row['productPrice'];
          echo '
		        <div class="cols-lg-4 cols-md-3 cols-sm-2 cols-2">
                  <div class="card " style="width: 18rem;">
                    <img src="img/menu-'.$id. '.jpg" class="card-img-top" alt="image for this product" width="249px" height="270px">
                    <div class="card-body">
                      <h5 class="card-title"><a style="color:#d87944 !important;" href="viewProductList.php?catid=' . $id . '">' . substr($cat, 0, 15). '...</a></h5>
                      <p class="card-text">' . substr($desc, 0, 20). '... </p>
                      <h5 style="color: #333"><b>AED '.$productPrice.'.00</b></h5>
					  <button class="btn btn-primary mx-2" data-toggle="modal" data-target="#loginModal" style="background-color:#426047 !important;border-color:#426047 !important;">Add to Cart</button>
					  <a href="viewProduct.php?productid=' . $id . '" class="mx-2"><button class="btn btn-primary" style="background-color:#426047 !important;border-color:#426047 !important;">Quick View</button></a>
                    </div>
                  </div>
                </div>';
        }
      ?>
    </div>
  </div>
</div>

    <?php require 'includes/_footer.php' ?>
 
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
</body>
</html>