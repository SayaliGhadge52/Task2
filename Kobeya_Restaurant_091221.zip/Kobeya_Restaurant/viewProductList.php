<!doctype html>
<html lang="en">
<head>
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title id="title">Category</title>
    <link rel = "icon" href ="img/kfavicon.png" type = "image/x-icon">
    <style>
	
	
	body {
    font-family: "open_sansregular" !important;
}
	
	
	
    .jumbotron {
        padding: 2rem 1rem;
    }
    #cont {
        min-height : 570px;
    }
	
		
.showcase-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  font-size: 1.6rem;
}

.main-title {
  text-transform: uppercase;
  margin-top: 1.5em;
}
	
#wrapper {
  overflow-x: hidden;
}

#sidebar-wrapper {
  min-height: 100vh;
  margin-left: -8rem;
  transition: margin 0.25s ease-out;
}

#sidebar-wrapper .sidebar-heading {
  padding: 0.875rem 1.25rem;
  font-size: 1.2rem;
}

#sidebar-wrapper .list-group {
  width: 15rem;
  height: 100%;
}

.list-group-item-light {
    color: #000000;
    background-color: #fefefe;
}

.card-body .wishlist{
	float: right;
}

a {
    color: #426047;
}
/*-------side-menu-----------*/
.side-menu{
	flex-grow:1;
	flex-basis: 300px;
	position:sticky;
	top: 2rem;
	padding-left: 15px;
    padding-right: 15px;
	height:79%;
	width: 15%;
	font-size: 15px;
	float: left;
	z-index: 0 ;
	background-color:#ffffff00;
	
}
.side-menu ul{
	margin-left: 10px;
}
.side-menu ul li{

	list-style-type: none;
	font-weight: bold;
	margin-top: 4px;
	margin-bottom: 4px;
	cursor: pointer;
	padding: 0 30px 5px 5px;
	border-bottom:  solid #fff;	
}
.side-menu ul li a:hover{
	color: orange;
	
}

.side-menu a {
  display: block;
  color: black;
  padding: 10px;
  text-decoration: none;
}
a{
    color: #000000;
}

.side-menu a.active {
  background-color: #ffffff00;

}

.side-menu a:hover:not(.active) {
  background-color: #555;
  color: white;
}

@media screen and (max-width: 700px) {
  .side-menu {
    width: 100%;
    height: auto;
    position: relative;
  }
  .side-menu a {float: left;}
  div.content {margin-left: 0;}
}

@media screen and (max-width: 400px) {
	
  .side-menu a {
    text-align: center;
    float: none;
  }
}
@media screen and (max-width: 900px) {
  
  
  .side-menu a {
    float: none;
    text-align: center;
	
  }
  

}

/*--------side end-------------------*/
    </style>
</head>
<body>
        <?php include 'includes/_dbconnect.php';
      error_reporting(0);
session_start();
    ?>
    <?php require 'includes/_nav.php' ?>

    <div>&nbsp;
        <a href="index.php" class="active text-dark">
        <i class="fas fa-qrcode"></i>
            <span>All Category</span>
        </a>
    </div>

    <?php
        $id = $_GET['catid'];
        $sql = "SELECT * FROM `categories` WHERE categorieId = $id";
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result)){
            $catname = $row['categorieName'];
            $catdesc = $row['categorieDesc'];
        }
    ?>
  
    <!-- Product container starts here -->
	
    
        
        <div class="col-lg-4 text-center bg-light my-3" style="margin:auto;border-bottom: 2px #426047;color:#426047 !important">     
            <h2 class="text-center"><span id="catTitle">Items</span></h2>
        </div>
		<div class="side-menu" id="side-menu">
                <ul>
                 <li style="color:#426047; text-decoration:underline solid 2px #000000;"><a class="active">Food Categories</a></li>
				 <li><a  href="viewProductList.php?catid=23">Breakfast</a></li>
				 <li><a href="viewProductList.php?catid=24">Appetizer & Soup</a></li>
				 <li><a href="viewProductList.php?catid=25">Salad</a></li>
				 <li><a href="viewProductList.php?catid=26">Main</a></li>
				 <li><a href="viewProductList.php?catid=29">Beverages</a></li>
				 <li><a href="viewProductList.php?catid=27">Combo</a></li>
				 <li><a href="viewProductList.php?catid=28">Dessert</a></li>
				 <li><a href="viewProductList.php?catid=30">Coffee & Tea</a></li>
				 <li><a href="viewProductList.php?catid=31">Kids Menu</a></li>
				 <li><a href="viewProductList.php?catid=32">Occasion Cakes</a></li>
				</ul>
               
        </div>
	 
        <div class="row">
        <?php
            $id = $_GET['catid'];
            $sql = "SELECT * FROM `product` WHERE productCategorieId = $id";
            $result = mysqli_query($conn, $sql);
            $noResult = true;
            while($row = mysqli_fetch_assoc($result)){
                $noResult = false;
                $productId = $row['productId'];
                $productName = $row['productName'];
                $productPrice = $row['productPrice'];
                $productDesc = $row['productDesc'];
            
                echo '<div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card" style="width: 18rem;">
                            <img src="img/menu-'.$productId. '.jpg" class="card-img-top" alt="image for this product" width="249px" height="270px">
                            <div class="card-body">
                                <h5 class="card-title">' . substr($productName, 0, 15). '...</h5>
                                <h5 style="color: #333"><b>AED '.$productPrice.'.00</b><span class="wishlist"><a href="wishlist.php?id=' .$id. '"><i class=" fa fa-heart" style="color: grey"></i></a></span></h5>
                                <p class="card-text">' . substr($productDesc, 0, 20). '...</p>   
                                <div class="row justify-content-center">';
                                if($loggedin){
                                    $quaSql = "SELECT `itemQuantity` FROM `viewcart` WHERE productId = '$productId' AND `userId`='$userId'";
                                    $quaresult = mysqli_query($conn, $quaSql);
                                    $quaExistRows = mysqli_num_rows($quaresult);
									while($quaExistRows1=mysqli_fetch_array($quaresult)){
									$Quantity=$quaExistRows1['itemQuantity'];
								
									echo '<form id="frm' . $productId . '">
                                                    <input type="hidden" name="productId" value="' . $productId . '">
                                                    <input type="number" name="quantity" value="' . $Quantity . '" class="text-center" onchange="updateCart(' . $productId . ')" onkeyup="return false" style="width:50px" ,border-color:#d87944 !important; min=1 oninput="check(this)" onClick="this.select();">
                                                </form>';
									}
                                    if($quaExistRows == 0) {
                                        echo '<form action="includes/_manageCart.php" method="POST">
                                              <input type="hidden" name="itemId" value="'.$productId. '">
                                              <button type="submit" name="addToCart" class="btn btn-primary mx-2" style="background-color:#426047 !important;border-color:#426047 !important;">Add to Cart</button>';
                                    }else {
                                        echo '<a href="viewCart.php"><button class="btn btn-primary mx-2" style="background-color:#ffff !important;border:none !important;"><i class="fas fa-shopping-cart" style="font-size:30px;color:#d87944";></i> 
<span style="color:#426047!important;position:relative;height:24px;width:24px;top:-25px; right:10px;font-weight:bold;"> '.$Quantity.'</span></button></a>' ;
										
                                    }
                                }
                                else{
                                    echo '<button class="btn btn-primary mx-2" data-toggle="modal" data-target="#loginModal" style="background-color:#426047 !important;border-color:#426047 !important;">Add to Cart</button>';
                                }
                            echo '</form>                            
                                <a href="viewProduct.php?productid=' . $productId . '" class="mx-2"><button class="btn btn-primary" style="background-color:#426047 !important;border-color:#426047 !important;">Quick View</button></a> 
                                </div>
                            </div>
                        </div>
                    </div>';
            }
            if($noResult) {
                echo '<div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <p class="display-4">Sorry In this category No items available.</p>
                        <p class="lead"> We will update Soon.</p>
                    </div>
                </div> ';
            }
            ?>
        </div>
   

    

    <?php require 'includes/_footer.php' ?>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
    <script> 
        document.getElementById("title").innerHTML = "<?php echo $catname; ?>"; 
        document.getElementById("catTitle").innerHTML = "<?php echo $catname; ?>"; 
    </script> 
</body>
</html>