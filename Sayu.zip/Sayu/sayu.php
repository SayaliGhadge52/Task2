<?php
include 'connection.php';
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Working Contact Form - Lear with Sharf - www.sharfslab.com</title>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta name="keywords" content="Working Contact Form HTML/PHP " />
<!--web-fonts-->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'></head>
<link href='//fonts.googleapis.com/css?family=Candal' rel='stylesheet' type='text/css'>
<!--web-fonts-->
<body>
		
		<!---main--->
			<div class="main-content">
				<div class="contact-w3">
                <!---header--->

		<div class="header">
		<center><img src="images/int_logo (2).png" alt="logo" class="logoright"></center>
			<h1>GUL FOOD 2022<br>Feedback Form</h1>
		</div>
		<!---header--->
					<form action="insert.php" method="post">
						
						<label>Date</label>
						<b><input type="text" name="name" placeholder="2/13, 2/14, 2/15, 2/16, 2/17"></b>
						<div class="row">
							<div class="contact-left-w3">
								<label>Company</label>
									<input type="text" name="company" placeholder="Company" required>
							</div>
							<div class="contact-right-w3l">
								<label>Phone</label>
								<input type="text" name="phone" placeholder="Phone number" required>
							</div>
							<div class="clear"></div>
						</div>
						<div class="row">
							<div class="contact-left-w3">
								<label>Contact</label>
									<input type="text" name="contact" placeholder="contact" required>
							</div>
							<div class="contact-right-w3l">
								<label>Fax</label>
								<input type="text" name="fax" placeholder="fax" required>
							</div>
							<div class="clear"></div>
						</div>
						<div class="row">
						<div class="contact-left-w3">
								<label>Mobile</label>
								<input type="text" name="mobile" placeholder="mobile" required>
						</div>
							<div class="contact-right-w3l">
								<label>Email</label>
									<input type="text" name="email" placeholder="Email address" required>
							</div>
							
							<div class="clear"></div>
						</div>
						<div class="row">
						    <label>Country</label>
							<table>
		<tr>
		
		 <?php
		     $query = "SELECT * FROM countries";
			 $query_run = mysqli_query($con, $query);
			 
			 if(mysqli_num_rows($query_run) > 0){
				 foreach($query_run as $row){
					?>
					<th><input type="checkbox" name="country" value="<?php echo $row['name'];?>"><?php echo $row['name'];?>
					<?php
				 }
			 } else {
				 echo "No record found";
			 }
		 ?>
		</tr>

		</table>
						</div>
						<input type="checkbox" name="others">Others
						<input type="text" name="others" placeholder="Pls,Specify">
						<div class="row">
							 <label>Product Interest</label>
			<select name="product_interest" id="product_interest">
               <option value="">Select...</option>
               <option value ="Kobe/Wagyu">Kobe/Wagyu</option>
               <option value ="Niigata Rice">Niigata Rice</option>
			   <option value ="Soy Burg">Soy Burg</option>
			   <option value ="Jackbean Tea">Jackbean Tea</option>
			   <option value ="Okara Powder">Okara Powder</option>
			   <option value ="Japanese Fruits">Japanese Fruits</option>
			   <option value ="Others">Others</option>
            </select>
						</div>
						
						<label>Samples</label>
							<input type="text" name="samples" placeholder="Samples" required>
						<div class="row1">
							<label>Remarks</label>
							<textarea placeholder="Remarks" name="remarks"></textarea>
						</div>
						
						<label>Attended By</label>
							<input type="text" name="attendedby" placeholder="Attended By" required>
							
						<label>Upload Image</label>	
						<input type="file" name="file">
						
						<div class="row">
						<label >Select Snapshot:</label></br>
                <div id="live_camera"></div>
                <br/>
               <input type=button value="Take Snapshot" onClick="capture_web_snapshot()">
                <input type="hidden" name="images" class="image-tag">
				
				 <div id="preview">Your captured image will appear here...</div>
						</div>
						
						<input type="submit" value="Submit">
					</form>
				</div>
			</div>
		<div class="footer-w3-agile">
			<p>&copy 2022 Gul Food Form . All rights reserved</p>
		</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js"></script>
<!-- Settings a few settings and (php capture image from camera) web attach camera -->
<script language="JavaScript">
    Webcam.set({
        width: 200,
        height: 150,
        image_format: 'jpeg',
        jpeg_quality: 90
    });
	
	 Webcam.set('constraints',{
        facingMode: "environment"
    });
  
    Webcam.attach( '#live_camera' );
  
    function capture_web_snapshot() {
		
        Webcam.snap( function(site_url) {
            $(".image-tag").val(site_url);
            document.getElementById('preview').innerHTML = '<img src="'+site_url+'"/>';
        } );
    }
	


</script>
		<!---main--->
</body>
</html>