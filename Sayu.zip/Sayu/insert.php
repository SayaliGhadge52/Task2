<?php

    require_once("connection.php");
	
	

    if(isset($_POST['submit']))
    {
        if(empty($_POST['company']) || empty($_POST['phone']) || empty($_POST['contact']) || empty($_POST['fax']) || empty($_POST['mobile'])|| empty($_POST['email']) || empty($_POST['product_interest']) || empty($_POST['samples']) || empty($_POST['remarks']) || empty($_POST['attendedby']))
        {
            echo ' Please Fill in the Blanks ';
        }
        else
        {
            $company = $_POST['company'];
            $phone = $_POST['phone'];
            $contact = $_POST['contact'];
			$fax = $_POST['fax'];
			$mobile = $_POST['mobile'];
			$email = $_POST['email'];
			$product_interest = $_POST['product_interest'];
			$samples = $_POST['samples'];
			$remarks = $_POST['remarks'];
			$attendedby = $_POST['attendedby'];
			$country=$_POST['country'];
			$others=$_POST['others'];
			$image = $_FILES['file']['name'];
			$tempname = $_FILES['file']['tmp_name'];    
            $folder = "images/".$image;
			
			 $myimg = $_POST['images'];
             $destinationPath = "upload/";
  
            $web_capture_part = explode(";base64,", $myimg);
            $image_type_aux = explode("images/", $web_capture_part[0]);
            //$image_type = $image_type_aux[1];
  
            $image_base64 = base64_decode($web_capture_part[1]);
            $myimgName = uniqid() . '.png';
  
            $file = $destinationPath . $myimgName;
            file_put_contents($file, $image_base64);
  
           // print_r($myimgName);
  

            $query = " insert into user (company, phone,contact,fax,mobile,email,product_interest,samples,remarks,attendedby,country,others,image) values('$company','$phone','$contact','$fax','$mobile','$email','$product_interest','$samples','$remarks','$attendedby','$country','$others','$image')";
            $result = mysqli_query($con,$query);
            
			  // Now let's move the uploaded image into the folder: image
            if (move_uploaded_file($tempname, $folder))  {
            $msg = "Image uploaded successfully";
            }else{
            $msg = "Failed to upload image";
            }
            if($result)
            {
                echo 'Thank You for your feedback!!';
            }
            else
            {
                echo '  Please Check Your Query ';
            }
        }
    }
    else
    {
        header("location:index.php");
    }



?>