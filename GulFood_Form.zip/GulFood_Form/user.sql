-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 10, 2022 at 03:44 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gul_food`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `company` varchar(100) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `fax` varchar(50) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `product_interest` varchar(50) NOT NULL,
  `samples` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `attendedby` varchar(100) NOT NULL,
  `country` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `company`, `phone`, `contact`, `fax`, `mobile`, `email`, `product_interest`, `samples`, `remarks`, `attendedby`, `country`, `image`) VALUES
(1, 'abc', '123456789', '123456789', '123456789', '0123456789', 'abc@abc.com', '', '', '', '', '', ''),
(2, 'abc', '0123456789', '0123456789', '0123456789', '0123456789', 'abc@abc.com', '', '', '', '', '', '156755583_111801097632848_3700684113612933754_n.jpg'),
(3, 'abc', '0123456789', '0123456789', '0123456789', '0123456789', 'abc@abc.com', '', '', '', '', '', '156755583_111801097632848_3700684113612933754_n.jpg'),
(4, 'abc', '123654789', '123654789', '123654789', '1236547896', 'abc@abc.com', '', '', '', '', '', 'Capture.PNG'),
(5, 'abc', '123654789', '123654789', '123654789', '1236547896', 'abc@abc.com', '', '', '', '', '', 'Capture.PNG'),
(6, 'abc', '123654789', '123654789', '123654789', '1236547896', 'abc@abc.com', '', '', '', '', '', 'Capture.PNG'),
(7, 'abc', 'abc', 'abc', 'abc', 'abc', 'text@xyz.com', 'Niigata Rice', 'test', 'test', 'test', '', '156755583_111801097632848_3700684113612933754_n.jpg'),
(8, 'abc', 'abc', 'abc', 'abc', 'abc', 'text@xyz.com', 'Niigata Rice', 'test', 'test', 'test', '', '156755583_111801097632848_3700684113612933754_n.jpg'),
(11, 'test', 'test', 'test', 'test', 'test', 'abc@abc.com', 'Jackbean Tea', 'test', 'tst', 'test', 'Oman', '156755583_111801097632848_3700684113612933754_n.jpg'),
(12, 'test', 'test', 'test', 'test', 'test', 'tx@txt.com', 'Niigata Rice', 'test', 'test', 'test', 'UAE', '1-10.png'),
(16, 'test', 'test', 'test', 'test', 'test', 'test@test.com', 'Soy Burg', 'test', 'test', 'test', 'Saudi', '246201900_248771197269170_3681325042491634895_n.jpg'),
(18, 'test', 'test', 'test', 'tset', 'test', 'abx@abc.com', 'Jackbean Tea', 'test', 'test', 'test', 'Saudi', 'Capture.PNG');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
