<?php 
$con=mysqli_connect("localhost","root","","gul_food"); 
if(!$con) { die(" Connection Error "); } 
?>
