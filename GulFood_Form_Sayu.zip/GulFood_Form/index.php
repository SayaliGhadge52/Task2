<?php
include 'connection.php';
?>
<!DOCTYPE html>
<html>
<head>
   <title>Gul Food 2022</title>
   <link rel="stylesheet" type="text/css" href="css/style.css">
   <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <script src="https://kit.fontawesome.com/67c66657c7.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>



<style type="text/css">
    #preview { padding:30px; border:1px solid; background:#3d3d3d; }
		
	textarea {
    padding: 10px;
    max-width: 100%;
    line-height: 1.5;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-shadow: 1px 1px 1px #999;
}
.logoright {
  float: right;
}

</style>
</head>

<body>


    <div class="form">
	<form autocomplete="off" enctype="multipart/form-data" action="insert.php" method="post">
	    <div class="banner">
	      
	    </div>
		<div class="site-logo" >
          <img src="images/ban.png" alt="logo">
		  <img src="images/int_logo (2).png" alt="logo" class="logoright">
        </div>
	    <h1>GUL FOOD 2022<br>Feedback Form</h1>
	
	    <div class="form-message">
	   
	    </div>
	    <div class="row">
	     <div class="field column">
		    <label>Date : <b>2/13, 2/14, 2/15, 2/16, 2/17</b></label>
		 </div>

	    </div>
		
		<div class="row">
		
		<div class="field column">
		    <label>Company: </label>
			<input type="text" name="company" required>
		 </div>
		 
		
		
	      <div class="field column">
		    <label>Phone : </label>
			<input type="phone" name="phone" required>
		 </div>
		 
	    </div>
		
		<div class="row">
		 <div class="field column">
		    <label>Contact : </label>
			<input type="contact" name="contact" required>
		 </div>
		 
	     <div class="field column">
		    <label>Fax : </label>
			<input type="fax" name="fax" required>
		 </div>
		 
	    </div>
		
		<div class="row">
		 <div class="field column">
		    <label>Mobile : </label>
			<input type="mobile" name="mobile" required>
		 </div>
		 
	     <div class="field column">
		    <label>Email : </label>
			<input type="email" name="email" required>
		 </div>
		 
	    </div>
        
			<div class="row">
		<div class="field column">
	    <label>Country : </label>
		<table>
		<tr>
		
		 <?php
		     $query = "SELECT * FROM countries";
			 $query_run = mysqli_query($con, $query);
			 
			 if(mysqli_num_rows($query_run) > 0){
				 foreach($query_run as $row){
					?>
					<th><input type="checkbox" name="country" value="<?php echo $row['name'];?>"><?php echo $row['name'];?>
					<?php
				 }
			 } else {
				 echo "No record found";
			 }
		 ?>
		</tr>

		</table>
		   <input type="checkbox" name="country"> Others
		 </div>
		</div>	
	
		<div class="row">
		 <div class="field column">
		    <label>Product Interest : </label>
			<select name="product_interest" id="product_interest">
               <option value="">Select...</option>
               <option value ="Kobe/Wagyu">Kobe/Wagyu</option>
               <option value ="Niigata Rice">Niigata Rice</option>
			   <option value ="Soy Burg">Soy Burg</option>
			   <option value ="Jackbean Tea">Jackbean Tea</option>
			   <option value ="Okara Powder">Okara Powder</option>
			   <option value ="Japanese Fruits">Japanese Fruits</option>
			   <option value ="Others">Others</option>
            </select>
		 </div>
		</div>
		
        <div class="row">		
	     <div class="field column">
		    <label>Samples : </label><br>
			<textarea name="samples" rows="2" cols="60"></textarea>
		 </div>
		 
	    </div>
		
		<div class="row">		
	     <div class="field column">
		    <label>Remarks : </label><br>
			<textarea name="remarks" rows="3" cols="60"></textarea>
		 </div>
		 
	    </div>
		
		<div class="row">
		 <div class="field column">
		    <label>Attended By : </label>
			<input type="text" name="attendedby" required>
		 </div>
		</div>
		
		<div class="row">
		 
		  <div class="field column">
		    <label>Upload Image : </label>
			<input type="file" name="file">
		  </div>
		  
		 
	    </div>
		<div class="row">
            <div class="field column">
			<label >Select Snapshot:</label></br>
                <div id="live_camera"></div>
                <br/>
               <input type=button value="Take Snapshot" onClick="capture_web_snapshot()">
                <input type="hidden" name="images" class="image-tag">
            </div>
            <div class="field column">
                <div id="preview">Your captured image will appear here...</div>
            </div>
        </div>
		
		<div class="row">
	      <div class="field column">
			<input type="submit" name="submit" value="Submit">
		 </div>
		</div>
	</form>
	</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js"></script>
<!-- Settings a few settings and (php capture image from camera) web attach camera -->
<script language="JavaScript">
    Webcam.set({
        width: 200,
        height: 150,
        image_format: 'jpeg',
        jpeg_quality: 90
    });
	
	 Webcam.set('constraints',{
        facingMode: "environment"
    });
  
    Webcam.attach( '#live_camera' );
  
    function capture_web_snapshot() {
		
        Webcam.snap( function(site_url) {
            $(".image-tag").val(site_url);
            document.getElementById('preview').innerHTML = '<img src="'+site_url+'"/>';
        } );
    }
	


</script>
<script>
function myFunction() {
  var checkBox = document.getElementById("country");
  var text = document.getElementById("text");
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
     text.style.display = "none";
  }
}
</script>

</body>
</html>
