<?php
include 'includes/_dbconnect.php';
include 'includes/function.php';
$coupon_code=get_safe_value($_POST['coupon_code']);
$res1=mysqli_query($conn,"select * from orders where discount_code='$coupon_code'");
   $rowcount=mysqli_fetch_array($res1);
//echo "select * from coupon_code where coupon_code='$coupon_code' and expired_on > '".date('Y-m-d')."'";
$res=mysqli_query($conn,"select * from coupon_code where coupon_code='$coupon_code' and expired_on > '".date('Y-m-d')."'");
//$check=(!$res)?mysqli_num_rows($res):0;
if($res1 && mysqli_num_rows($res1)==0)
if( mysqli_num_rows($res)>0){
    $row=mysqli_fetch_assoc($res);	
	
	$arr=array('status'=>'success','msg'=>'coupon code applay.','final_value'=>$row['coupon_value']);

}else{
	$arr=array('status'=>'error','msg'=>'Please enter valid coupon code.');
}
else{
	$arr=array('status'=>'error','msg'=>'Coupon code already used by user.');
	
}
echo json_encode($arr);
?>